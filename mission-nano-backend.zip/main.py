from fastapi import FastAPI, Request
from datetime import datetime

app = FastAPI(
    title="Mission Nano Universe",
    description="Backend by Himmat 🚀",
    version="1.0.0"
)

@app.get("/")
async def root():
    return {
        "status": "ok",
        "message": "Mission Nano Backend running ✅",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

@app.post("/ai/chat")
async def chat(data: dict, request: Request):
    prompt = data.get("prompt", "")
    if not prompt:
        return {"error": "No prompt provided."}
    return {
        "reply": f"🤖 Hello Himmat! You said: '{prompt}'",
        "client": request.client.host
    }
